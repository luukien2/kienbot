# Silencert - A bot to automatic delete joining and leaving message on Telegram supergroup.

## Requirements

- Python 3.4 or higher.
- pyrogram - Telegram MTProto API Client Library for Python

## Getting Started

```bash
pip install -r requirements.txt
python3 bot.py
```
Log in your group admin account with the prompt (only do this once).